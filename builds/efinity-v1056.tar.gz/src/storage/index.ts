import * as system from './system'

const storage = { system }

export default storage
