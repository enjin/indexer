export enum FeeSide {
    NoFee = "NoFee",
    Make = "Make",
    Take = "Take",
}
