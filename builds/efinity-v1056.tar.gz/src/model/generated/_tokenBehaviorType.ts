export enum TokenBehaviorType {
    HasRoyalty = "HasRoyalty",
    IsCurrency = "IsCurrency",
}
