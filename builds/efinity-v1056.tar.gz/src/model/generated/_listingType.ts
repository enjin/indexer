export enum ListingType {
    FixedPrice = "FixedPrice",
    Auction = "Auction",
}
