export enum CapType {
    SingleMint = "SingleMint",
    Supply = "Supply",
}
