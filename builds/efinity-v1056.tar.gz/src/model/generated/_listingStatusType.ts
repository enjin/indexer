export enum ListingStatusType {
    Active = "Active",
    Cancelled = "Cancelled",
    Finalized = "Finalized",
}
