// import * as extrinsics from './calls'
import * as events from './events'
import * as processor from './processor'

export default {
    // extrinsics,
    events,
    processor,
}
